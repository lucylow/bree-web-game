# BREE Feature Audit

**Build:** browser prototype / single-player slice. Status reflects actual connected behavior, not the presence of a screen or a placeholder record.

## Implemented and regression-tested

| Feature group | Evidence in this build |
| --- | --- |
| Shared single-player state and progression | Typed reducer connects household tasks, travel, cooking, dialogue, evidence, hosting, estate upgrades, time, needs, money, and XP. |
| Mission rewards | M001 supper, M004 garden improvement, and M007 apple cake grant rewards once; the test suite guards against repeat farming. |
| Recipe and pantry loop | 15 recipes use the typed inventory; cooking checks stock and energy, consumes ingredients, advances time, and updates dish quality. |
| Daily needs and routine | Energy, composure, hunger, cleanliness, social fulfillment, and household condition are visible. Breakfast, garden watering, bulletin reading, messages, tidy, talk, cooking, hosting, and rest affect state. |
| Need difficulty | Relaxed, standard, and challenging overnight decay rates are selectable and tested. |
| Daily calendar and upkeep | Day advancement resets day tasks, starts at 8 a.m., applies household expense, and recovers energy; tests check the daily transition. |
| Climate and events | Four seven-day season blocks; six cycling weather states; a repeatable seeded event deck every third day. Weather gates garden watering. |
| Neighborhood report | Seven bounded measures contribute to a composite status score; relationship, cohesion, funds, estate level, season, weather, and repairs feed the report. |
| Evidence and content validation | Four clue records, five rumor records, four secret records; references and unique IDs are validated. Clue inspection moves the player to its location. |
| Persistence and recovery logic | Three manual slots, autosave, v1 hydration, local backup rotation, corrupt-primary preservation, and backup selection. Core recovery behavior is unit-tested. |
| Responsive/accessibility foundations | Responsive CSS, visible keyboard focus styles, reduced-motion preference, and standard semantic buttons/labels are present. Mobile device/browser testing is not claimed. |

**Automated checks:** `npm run build` succeeds; `npm test` passes 12 reducer/content/recovery tests. The production bundle was built for the delivered ZIP.

## Partially implemented

| Plan area | What exists | What is still missing |
| --- | --- | --- |
| World that feels alive (P1–10) | Weather, seasons, day period, daily upkeep/events, a computed world score, and needs change over play. | Residents do not follow schedules or autonomously move/interact; businesses have no operating hours; events are limited and do not model the full neighborhood. Day/night uses interface styling, not full scene lighting. |
| Character/social systems (P11–19) | 12 profiles, static personality/preferences/skills, a relationship meter, and gracious/candid dialogue outcomes. | No persistent emotional memory, autonomous routine, rivalry, emotional state machine, personal quest chains, or character-to-character simulation. |
| Story/missions (P21–30) | Three campaign hooks are playable; some clues, secrets, and completion IDs persist. | No 12-chapter narrative, large side-story catalog, fully solvable mystery chain, story recap/cutscenes, multiple endings, or broad decision-flag system. Seven included sample briefs remain locked. |
| Cooking/catering (P41–50) | 15 recipes and pantry quantities, cooking time/quality, and recipe-level unlocks. | No ingredient freshness/storage limits, cooking mini-games, equipment tree, contracts, reviews, staffing, or competitions. |
| Estate/business (P51–60) | One repeatable garden-improvement path affects funds, prestige, cohesion, and status. | No 50 buildings, interior/exterior placement editor, property income/operating model, staff morale/schedules/training, or multi-resource projects. |
| Community/social (P61–70) | Reputation, cohesion, clues/rumors, a neighborhood roster, and one supper event. | No policy meetings/voting, fairness model, guest seating, social-topic simulation, robust conflict resolution, or generated newspaper. |
| Economy/progression (P71–80) | Shared funds, market restock, mission rewards, XP/levels, garden upgrades, and daybreak expense. | No multiple income sources, weekly accounting/savings goals, market variation, specializations, achievements, collections, or mastery tracks. |
| Onboarding, saves, and validation (P81–90) | Contextual labels; local saves, backups and migration; typed-data validation; unit tests. | No guided tutorial, search/filtering, import/export, performance telemetry, or browser-based/mobile-device test suite. Storage failures are surfaced, but recovery cannot reconstruct data that has no valid local copy. |

## Not implemented

- Action-game movement, collision, stealth, gadgets, action missions, rankings, and action accessibility scenarios (P31–40).
- 100 original recipes and the larger numerical content targets (P30, P41, P51, P99).
- New Game Plus, challenge mode, photo mode, character/home customization, and multiplayer architecture (P91–96).
- Versioned downloadable content packs, release deployment pipeline, production analytics, or online account/cloud services (P97–100).
- Full acceptance set of 20+ missions, 30+ recipes, 15+ characters, three chapters, staff, catering, policy influence, and achievements (P99–100).

## Development priorities

1. Deepen the single-player mission chain and keep its rewards tied to testable objective transitions.
2. Add resident schedules and situational dialogue using the current profile data without requiring online AI.
3. Add catering contracts and a small staff/project system with explicit costs and daily outcomes.
4. Expand content in validated versioned packs; add browser/mobile interaction coverage before calling the prototype release-ready.
