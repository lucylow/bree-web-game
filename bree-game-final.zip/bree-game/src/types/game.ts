export type Screen = 'home' | 'neighborhood' | 'missions' | 'kitchen' | 'supper' | 'estate' | 'people' | 'journal' | 'settings';
export type ItemId = 'flour' | 'eggs' | 'butter' | 'lemon' | 'apple' | 'cream' | 'sugar' | 'herbs' | 'tea' | 'flowers';
export type RecipeId = 'lemon-tart' | 'apple-cake' | 'herb-scones' | 'cream-puffs' | 'tea-cakes' | 'garden-salad' | 'lemon-curd' | 'shortbread' | 'apple-tart' | 'savory-pie' | 'tea-loaf' | 'butter-biscuits' | 'summer-trifle' | 'garden-quiche' | 'honey-cake';
export type NeedDifficulty = 'relaxed' | 'standard' | 'challenging';
export type Weather = 'Sunny' | 'Cloudy' | 'Rainy' | 'Stormy' | 'Foggy' | 'Snowy';
export type Season = 'Spring' | 'Summer' | 'Autumn' | 'Winter';
export type DayPeriod = 'morning' | 'afternoon' | 'evening' | 'night';
export type ActivityId = 'breakfast' | 'water-garden' | 'read-paper' | 'check-messages';
export interface Recipe { id: RecipeId; name: string; subtitle: string; icon: string; ingredients: Partial<Record<ItemId, number>>; steps: string[]; minutes: number; unlockAt: number; }
export interface Character { id: string; name: string; role: string; avatar: string; description: string; opening: string; gracious: string; candid: string; personality: string[]; occupation: string; homeLocationId: string; skills: Record<string, number>; likes: string[]; dislikes: string[]; startingRelationship: number; secretIds: string[]; }
export interface GameState {
  version: 1; playerName: string; day: number; hour: number; minute: number; energy: number; composure: number; hunger: number; cleanliness: number; socialFulfillment: number; householdCondition: number; needDifficulty: NeedDifficulty;
  weather: Weather; season: Season; dailyEvent: string | null; reputation: number; funds: number; xp: number; level: number; location: string;
  inventory: Record<ItemId, number>; relationships: Record<string, number>; talkedTo: string[]; dish: { name: string; quality: number; icon: string } | null;
  tidied: boolean; cooked: boolean; greeted: boolean; hosted: boolean; missionComplete: boolean; completedMissionIds: string[]; collectedClues: string[]; estateLevel: number; prestige: number; cohesion: number; log: string[]; sound: boolean; reducedMotion: boolean;
}
export interface SaveSlot { savedAt: string; state: GameState; }
export type GameAction =
  | { type: 'tidy' } | { type: 'travel'; location: string } | { type: 'cook'; recipe: Recipe } | { type: 'shop' }
  | { type: 'talk'; characterId: string; tone: 'gracious' | 'candid'; characterName: string; delta: number }
  | { type: 'investigate'; clueId: string } | { type: 'activity'; activity: ActivityId } | { type: 'difficulty'; value: NeedDifficulty }
  | { type: 'host' } | { type: 'upgrade' } | { type: 'rest' } | { type: 'newDay' }
  | { type: 'rename'; name: string } | { type: 'setting'; key: 'sound' | 'reducedMotion'; value: boolean }
  | { type: 'load'; state: GameState };
