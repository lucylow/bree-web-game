import type { DayPeriod, GameAction, GameState, ItemId, SaveSlot } from '../types/game';
import { clueRecords, worldCharacters, worldLocations } from '../data/world';

export const SAVE_KEY = 'bree-save-v1';
const levelFromXp = (xp: number) => Math.min(5, Math.floor(xp / 70) + 1);
const clamp = (value: number) => Math.max(0, Math.min(100, Math.round(value)));
const seasons = ['Spring', 'Summer', 'Autumn', 'Winter'] as const;
const weatherCycle = ['Sunny', 'Cloudy', 'Rainy', 'Foggy', 'Stormy', 'Snowy'] as const;
const eventDeck = ['An unexpected neighbor drops by. A kind word lifts the lane.', 'A produce basket arrives at the front step. One extra apple for the pantry.', 'The old kettle needs a repair; the household pays $12.'] as const;
export const dayPeriod = (hour: number): DayPeriod => hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : hour < 20 ? 'evening' : 'night';
const seasonForDay = (day: number) => seasons[Math.floor((day - 1) / 7) % seasons.length];
const weatherForDay = (day: number) => weatherCycle[(day - 1) % weatherCycle.length];
export const freshGame = (playerName = 'Bree'): GameState => ({
  version: 1, playerName: playerName.trim().slice(0, 24) || 'Bree', day: 1, hour: 8, minute: 0,
  energy: 88, composure: 78, hunger: 72, cleanliness: 74, socialFulfillment: 42, householdCondition: 78, needDifficulty: 'standard',
  weather: 'Sunny', season: 'Spring', dailyEvent: null, reputation: 32, funds: 240, xp: 0, level: 1,
  location: 'Bree’s Residence', inventory: { flour: 3, eggs: 4, butter: 3, lemon: 2, apple: 3, cream: 2, sugar: 3, herbs: 3, tea: 2, flowers: 1 },
  relationships: Object.fromEntries(worldCharacters.map((person) => [person.id, person.startingRelationship])), talkedTo: [], dish: null,
  tidied: false, cooked: false, greeted: false, hosted: false, missionComplete: false, completedMissionIds: [], collectedClues: [],
  estateLevel: 0, prestige: 18, cohesion: 54, log: ['A garden supper is planned for this evening. The house, naturally, has other ideas.'], sound: false, reducedMotion: false,
});

export function hydrateGameState(value: unknown): GameState {
  if (!value || typeof value !== 'object') return freshGame();
  const saved = value as Partial<GameState>;
  if (saved.version !== 1 || !saved.inventory) return freshGame(saved.playerName ?? 'Bree');
  const defaults = freshGame(saved.playerName ?? 'Bree');
  return {
    ...defaults,
    ...saved,
    inventory: { ...defaults.inventory, ...saved.inventory },
    relationships: { ...defaults.relationships, ...(saved.relationships ?? {}) },
    completedMissionIds: Array.isArray(saved.completedMissionIds) ? saved.completedMissionIds : saved.missionComplete ? ['M001'] : [],
    collectedClues: Array.isArray(saved.collectedClues) ? saved.collectedClues : [],
  };
}

export function recoverAutosave(primaryRaw: string | null, backupRaw: string | null): { state: GameState; source: 'primary' | 'backup' | 'fresh'; damagedPrimary: string | null } {
  const parse = (raw: string): GameState => {
    const value: unknown = JSON.parse(raw);
    if (!value || typeof value !== 'object' || Array.isArray(value) || !('version' in value) || value.version !== 1 || !('inventory' in value)) throw new Error('Unsupported or incomplete save data.');
    return hydrateGameState(value);
  };
  if (primaryRaw !== null) {
    try { return { state: parse(primaryRaw), source: 'primary', damagedPrimary: null }; }
    catch {
      try { return { state: parse(backupRaw ?? ''), source: 'backup', damagedPrimary: primaryRaw }; }
      catch { return { state: freshGame(), source: 'fresh', damagedPrimary: primaryRaw }; }
    }
  }
  if (backupRaw !== null) {
    try { return { state: parse(backupRaw), source: 'backup', damagedPrimary: null }; }
    catch { return { state: freshGame(), source: 'fresh', damagedPrimary: null }; }
  }
  return { state: freshGame(), source: 'fresh', damagedPrimary: null };
}

export function addLog(state: GameState, message: string): GameState {
  return { ...state, log: [message, ...state.log].slice(0, 8) };
}
export function advanceTime(state: GameState, minutes: number): GameState {
  const total = state.hour * 60 + state.minute + minutes;
  const day = state.day + Math.floor(total / (24 * 60));
  const clock = total % (24 * 60);
  const hour = Math.floor(clock / 60);
  const minute = clock % 60;
  const energy = Math.max(0, Math.min(100, state.energy - Math.max(1, Math.ceil(minutes / 45))));
  const composure = Math.max(0, Math.min(100, state.composure - Math.max(0, Math.floor(minutes / 60))));
  const hunger = clamp(state.hunger - Math.max(0, Math.floor(minutes / 45)));
  return { ...state, day, hour, minute, energy, composure, hunger };
}
export function neighborhoodStatus(state: GameState) {
  const relationships = Object.values(state.relationships);
  const averageRapport = relationships.length ? relationships.reduce((sum, value) => sum + value, 0) / relationships.length : 40;
  const rows = [
    { label: 'Community cohesion', value: state.cohesion },
    { label: 'Public reputation', value: state.reputation },
    { label: 'Infrastructure', value: clamp(35 + state.estateLevel * 14) },
    { label: 'Resident satisfaction', value: clamp(averageRapport * .55 + state.socialFulfillment * .45) },
    { label: 'Economic stability', value: clamp(35 + state.funds / 22) },
    { label: 'Neighborhood safety', value: clamp(55 + state.cohesion * .25 - (state.dailyEvent?.includes('repair') ? 8 : 0)) },
    { label: 'Environmental quality', value: clamp(38 + state.estateLevel * 8 + (state.season === 'Spring' ? 10 : 0) + (state.weather === 'Rainy' ? 4 : 0)) },
  ];
  return { score: clamp(rows.reduce((sum, row) => sum + row.value, 0) / rows.length), rows };
}
export function hasIngredients(inventory: Record<ItemId, number>, requirements: Partial<Record<ItemId, number>>): boolean {
  return Object.entries(requirements).every(([item, amount]) => inventory[item as ItemId] >= (amount ?? 0));
}
export function missionObjectives(state: GameState) {
  return [
    { id: 'tidy', label: 'Restore order to the foyer', done: state.tidied },
    { id: 'cook', label: 'Prepare a dish worthy of company', done: state.cooked },
    { id: 'greet', label: 'Check in with a neighbor', done: state.greeted },
    { id: 'host', label: 'Host the garden supper', done: state.hosted },
  ];
}
export function getSaveSlots(): Record<number, SaveSlot | null> {
  try {
    const parsed = JSON.parse(localStorage.getItem(SAVE_KEY) || '{}') as Record<string, SaveSlot>;
    return { 1: parsed['1'] ?? null, 2: parsed['2'] ?? null, 3: parsed['3'] ?? null };
  } catch { return { 1: null, 2: null, 3: null }; }
}
export function saveToSlot(state: GameState, slot: number): void {
  const slots = getSaveSlots();
  slots[slot] = { savedAt: new Date().toISOString(), state: { ...state } };
  localStorage.setItem(SAVE_KEY, JSON.stringify(slots));
}
export function reducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'load': return action.state;
    case 'rename': return { ...state, playerName: action.name.trim().slice(0, 24) || state.playerName };
    case 'setting': return { ...state, [action.key]: action.value };
    case 'tidy': {
      if (state.tidied) return state;
      const next = advanceTime(state, 15);
      return addLog({ ...next, tidied: true, cleanliness: clamp(next.cleanliness + 24), householdCondition: clamp(next.householdCondition + 8), composure: clamp(next.composure + 8), xp: next.xp + 10 }, 'Foyer restored. The crooked runner has been returned to civilization.');
    }
    case 'travel': {
      if (action.location === state.location) return state;
      const next = advanceTime(state, 10);
      return addLog({ ...next, location: action.location }, `You arrive at ${action.location}. A brisk walk, and only one neighbor noticed.`);
    }
    case 'cook': {
      if (state.energy < 8 || !hasIngredients(state.inventory, action.recipe.ingredients)) return state;
      const next = advanceTime(state, action.recipe.minutes);
      const inventory = { ...next.inventory };
      Object.entries(action.recipe.ingredients).forEach(([item, quantity]) => { inventory[item as ItemId] -= quantity ?? 0; });
      const quality = Math.max(48, Math.min(100, Math.round(72 + state.composure * 0.18 + (state.estateLevel ? 3 : 0))));
      const completedBefore = state.cooked;
      const cooked = true;
      const cakeMission = action.recipe.id === 'apple-cake' && !state.completedMissionIds.includes('M007');
      const xp = next.xp + 18 + (cakeMission ? 75 : 0);
      const completedMissionIds = cakeMission ? [...state.completedMissionIds, 'M007'] : state.completedMissionIds;
      const rewardText = cakeMission ? ' Mission M007 complete: +$125 and 75 experience.' : '';
      return addLog({ ...next, inventory, cleanliness: clamp(next.cleanliness - 3), dish: { name: action.recipe.name, quality, icon: action.recipe.icon }, cooked, xp, funds: next.funds + (cakeMission ? 125 : 0), completedMissionIds, level: levelFromXp(xp) }, `${action.recipe.name} is ready at ${quality}% quality.${completedBefore ? ' The pantry has been updated.' : ' Your first supper dish is prepared.'}${rewardText}`);
    }
    case 'shop': {
      if (state.funds < 48) return state;
      const next = advanceTime(state, 10);
      const inventory = { ...next.inventory, flour: next.inventory.flour + 2, eggs: next.inventory.eggs + 2, butter: next.inventory.butter + 1, lemon: next.inventory.lemon + 1, apple: next.inventory.apple + 1, cream: next.inventory.cream + 1, sugar: next.inventory.sugar + 1, herbs: next.inventory.herbs + 1 };
      return addLog({ ...next, inventory, funds: next.funds - 48 }, 'Market basket delivered: flour, eggs, butter, and a few useful odds and ends.');
    }
    case 'talk': {
      const old = state.relationships[action.characterId] ?? 40;
      const relationship = Math.max(0, Math.min(100, old + action.delta));
      const next = advanceTime(state, 12);
      const hasTalked = state.talkedTo.includes(action.characterId);
      const xp = next.xp + (hasTalked ? 2 : 8);
      return addLog({ ...next, relationships: { ...state.relationships, [action.characterId]: relationship }, talkedTo: hasTalked ? state.talkedTo : [...state.talkedTo, action.characterId], greeted: state.greeted || !hasTalked, socialFulfillment: clamp(next.socialFulfillment + (action.tone === 'gracious' ? 14 : 9)), reputation: Math.min(100, state.reputation + (action.tone === 'gracious' ? 2 : 1)), xp, level: levelFromXp(xp) }, `${action.characterName} appreciated your ${action.tone} approach. Relationship +${action.delta}.`);
    }
    case 'investigate': {
      const clue = clueRecords.find((record) => record.id === action.clueId);
      if (!clue || state.collectedClues.includes(clue.id)) return state;
      const next = advanceTime(state, 15);
      const location = worldLocations.find((place) => place.code === clue.locationId)?.id ?? state.location;
      return addLog({ ...next, location, collectedClues: [...state.collectedClues, clue.id], xp: next.xp + 5 }, `Evidence noted at ${location}: ${clue.name}. It may support a rumor, but it does not settle the story by itself.`);
    }
    case 'activity': {
      if (action.activity === 'breakfast') {
        if (state.funds < 8) return state;
        const next = advanceTime(state, 20);
        return addLog({ ...next, funds: next.funds - 8, hunger: clamp(next.hunger + 36), energy: clamp(next.energy + 5), xp: next.xp + 4 }, 'A sensible breakfast restores your appetite and energy. Household expense: $8.');
      }
      if (action.activity === 'water-garden') {
        if (state.weather === 'Rainy' || state.weather === 'Stormy' || state.weather === 'Snowy') return state;
        const next = advanceTime(state, 15);
        const seasonalBonus = state.season === 'Spring' || state.season === 'Summer' ? 10 : 4;
        return addLog({ ...next, householdCondition: clamp(next.householdCondition + seasonalBonus), cohesion: clamp(next.cohesion + 1), xp: next.xp + 5 }, `The garden gets a little care under a ${state.weather.toLowerCase()} ${state.season.toLowerCase()} sky. Household condition +${seasonalBonus}.`);
      }
      if (action.activity === 'read-paper') {
        const next = advanceTime(state, 15);
        return addLog({ ...next, composure: clamp(next.composure + 8), reputation: clamp(next.reputation + 1), xp: next.xp + 3 }, 'You read the neighborhood bulletin. One useful notice, two very confident opinions.');
      }
      const next = advanceTime(state, 10);
      return addLog({ ...next, socialFulfillment: clamp(next.socialFulfillment + 8), xp: next.xp + 2 }, 'You check the neighborhood messages and answer a friend. The lane feels a little closer.');
    }
    case 'difficulty': return { ...state, needDifficulty: action.value };
    case 'host': {
      if (!state.dish || state.hosted || state.missionComplete || !state.tidied || !state.greeted) return state;
      const next = advanceTime(state, 45);
      const score = Math.min(100, Math.round(state.dish.quality * 0.65 + state.composure * 0.2 + state.reputation * 0.15));
      const reward = 150;
      const xp = next.xp + 50;
      return addLog({ ...next, hosted: true, missionComplete: true, completedMissionIds: state.completedMissionIds.includes('M001') ? state.completedMissionIds : [...state.completedMissionIds, 'M001'], hunger: clamp(next.hunger - 8), socialFulfillment: clamp(next.socialFulfillment + 22), householdCondition: clamp(next.householdCondition - 2), funds: next.funds + reward, reputation: Math.min(100, next.reputation + 12), prestige: next.prestige + 5 + Math.ceil(score / 20), cohesion: Math.min(100, next.cohesion + 8), xp, level: levelFromXp(xp) }, `Garden supper complete — ${score}% guest satisfaction. Mission M001 complete: +$${reward}, 50 experience, reputation, and neighborhood prestige.`);
    }
    case 'upgrade': {
      const cost = 90 + state.estateLevel * 65;
      if (state.funds < cost) return state;
      const next = advanceTime(state, 60);
      const gardenMission = !state.completedMissionIds.includes('M004');
      const xp = state.xp + 15 + (gardenMission ? 25 : 0);
      const completedMissionIds = gardenMission ? [...state.completedMissionIds, 'M004'] : state.completedMissionIds;
      const bonus = gardenMission ? 250 : 0;
      return addLog({ ...next, funds: next.funds - cost + bonus, estateLevel: state.estateLevel + 1, prestige: state.prestige + 14 + (gardenMission ? 10 : 0), cohesion: Math.min(100, state.cohesion + 4), xp, completedMissionIds, level: levelFromXp(xp) }, gardenMission ? 'The Wisteria Green beds are upgraded. Mission M004 complete: +$250, 25 experience, and 10 prestige.' : 'The Wisteria Green garden beds are upgraded. The whole lane looks a little more hopeful.');
    }
    case 'rest': {
      const next = advanceTime(state, 30);
      return addLog({ ...next, energy: Math.min(100, next.energy + 25), composure: Math.min(100, next.composure + 18) }, 'A quiet cup of tea restores a measure of perspective. And stamina.');
    }
    case 'newDay': {
      const nextDay = state.day + 1;
      const decayRate = state.needDifficulty === 'relaxed' ? .5 : state.needDifficulty === 'challenging' ? 1.5 : 1;
      const dailyEvent = nextDay % 3 === 0 ? eventDeck[Math.floor(((nextDay * 37 + 17) % 100) / 35) % eventDeck.length] : null;
      const eventIndex = dailyEvent ? eventDeck.indexOf(dailyEvent) : -1;
      const inventory = eventIndex === 1 ? { ...state.inventory, apple: state.inventory.apple + 1 } : state.inventory;
      const funds = Math.max(0, state.funds - 25 - (eventIndex === 2 ? 12 : 0));
      const next = { ...state, day: nextDay, hour: 8, minute: 0, energy: 100, composure: clamp(state.composure + 12), hunger: clamp(state.hunger - 22 * decayRate), cleanliness: clamp(state.cleanliness - 8 * decayRate), socialFulfillment: clamp(state.socialFulfillment - 10 * decayRate + (eventIndex === 0 ? 8 : 0)), householdCondition: clamp(state.householdCondition - 5 * decayRate - (eventIndex === 2 ? 4 : 0)), funds, inventory, dailyEvent, weather: weatherForDay(nextDay), season: seasonForDay(nextDay), tidied: false, greeted: false, hosted: false, cooked: false, dish: null, talkedTo: [] };
      return addLog(next, `Day ${next.day} begins · ${next.season}, ${next.weather}. $25 household expenses paid.${dailyEvent ? ` ${dailyEvent}` : ''}`);
    }
  }
}
