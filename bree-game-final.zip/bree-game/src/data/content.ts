import type { ItemId, Recipe } from '../types/game';

export const itemLabels: Record<ItemId, { name: string; icon: string }> = {
  flour: { name: 'Flour', icon: '◌' }, eggs: { name: 'Eggs', icon: '◉' }, butter: { name: 'Butter', icon: '▰' }, lemon: { name: 'Lemons', icon: '◒' }, apple: { name: 'Apples', icon: '●' }, cream: { name: 'Cream', icon: '◍' }, sugar: { name: 'Sugar', icon: '✧' }, herbs: { name: 'Garden herbs', icon: '❧' }, tea: { name: 'Tea leaves', icon: '♨' }, flowers: { name: 'Flowers', icon: '✿' },
};

const basic = (id: Recipe['id'], name: string, subtitle: string, icon: string, ingredients: Partial<Record<ItemId, number>>, steps: string[], minutes = 30, unlockAt = 1): Recipe => ({ id, name, subtitle, icon, ingredients, steps, minutes, unlockAt });
export const recipes: Recipe[] = [
  basic('lemon-tart', 'Lemon tart', 'Bright citrus, immaculate timing.', '◒', { flour: 1, eggs: 1, butter: 1, lemon: 1 }, ['Measure with care', 'Whisk the filling', 'Bake until just set'], 35),
  basic('apple-cake', 'Apple cake', 'A dependable family favorite.', '◉', { flour: 1, eggs: 1, apple: 2, sugar: 1 }, ['Slice the apples', 'Fold the batter', 'Bake until golden'], 40),
  basic('herb-scones', 'Garden herb scones', 'Savory, fragrant, and unexpectedly chic.', '❧', { flour: 1, butter: 1, cream: 1, herbs: 1 }, ['Rub in the butter', 'Fold in the herbs', 'Bake close together'], 28),
  basic('cream-puffs', 'Cream puffs', 'Small, airy, and difficult to stop at one.', '◍', { flour: 1, eggs: 2, butter: 1, cream: 1 }, ['Make the choux', 'Pipe neat rounds', 'Fill when cool'], 48, 2),
  basic('tea-cakes', 'Afternoon tea cakes', 'A little sweetness goes a long way.', '✧', { flour: 1, eggs: 1, butter: 1, sugar: 1 }, ['Cream butter and sugar', 'Beat in the egg', 'Bake in small tins'], 32),
  basic('garden-salad', 'Garden salad', 'Crisp leaves with a proper dressing.', '❧', { herbs: 2, lemon: 1 }, ['Wash the greens', 'Whisk lemon dressing', 'Toss just before serving'], 15),
  basic('lemon-curd', 'Lemon curd', 'Silky, tart, and pleasingly versatile.', '◒', { lemon: 2, eggs: 2, sugar: 1, butter: 1 }, ['Zest the lemons', 'Stir over gentle heat', 'Chill until glossy'], 24, 2),
  basic('shortbread', 'Celebration shortbread', 'A crisp biscuit for important occasions.', '▰', { flour: 1, butter: 2, sugar: 1 }, ['Combine without overworking', 'Press into a tin', 'Score before baking'], 36),
  basic('apple-tart', 'Caramel apple tart', 'A little drama, entirely intentional.', '●', { flour: 1, apple: 2, butter: 1, sugar: 1 }, ['Arrange the apples', 'Caramelize the sugar', 'Turn out with confidence'], 42, 2),
  basic('savory-pie', 'Sunday savory pie', 'Comfort food with excellent posture.', '◉', { flour: 2, eggs: 1, butter: 1, herbs: 1 }, ['Prepare the pastry', 'Season the filling', 'Seal and bake'], 50, 2),
  basic('tea-loaf', 'Spiced tea loaf', 'Best served with a second cup.', '♨', { flour: 1, eggs: 1, tea: 1, sugar: 1 }, ['Steep the tea', 'Fold through the batter', 'Let it rest before slicing'], 44, 2),
  basic('butter-biscuits', 'Butter biscuits', 'A reassuringly precise classic.', '▰', { flour: 1, butter: 1, sugar: 1 }, ['Cream until pale', 'Cut into even rounds', 'Bake until the edges blush'], 26),
  basic('summer-trifle', 'Summer garden trifle', 'Layers of fruit, cream, and good judgment.', '◍', { apple: 1, cream: 2, sugar: 1, tea: 1 }, ['Steep the fruit', 'Layer cake and cream', 'Chill before unveiling'], 22, 2),
  basic('garden-quiche', 'Garden quiche', 'A centerpiece that prefers punctuality.', '✿', { flour: 1, eggs: 2, cream: 1, herbs: 1 }, ['Blind-bake the crust', 'Whisk the custard', 'Bake until softly set'], 46, 2),
  basic('honey-cake', 'Honey celebration cake', 'Sweet, golden, and worth the occasion.', '✧', { flour: 2, eggs: 2, butter: 1, sugar: 1 }, ['Whisk the eggs', 'Fold in the honey', 'Glaze while warm'], 52, 3),
];
