import { recipes } from './content';

export interface WorldCharacter {
  id: string; name: string; role: string; avatar: string; description: string; opening: string; gracious: string; candid: string;
  personality: string[]; occupation: string; homeLocationId: string; skills: Record<string, number>; likes: string[]; dislikes: string[];
  startingRelationship: number; secretIds: string[];
}
export interface WorldLocation { code: string; id: string; label: string; kind: string; note: string; }
export interface MissionDefinition {
  id: string; title: string; type: string; difficulty: 'Easy' | 'Medium' | 'Hard'; locationId: string; description: string;
  objectives: string[]; reward: { currency: number; experience: number; prestige?: number }; playable: boolean; unlockRecipeId?: string;
}
export interface ClueRecord { id: string; name: string; locationId: string; description: string; value: number; }
export interface GossipRecord { id: string; sourceId: string; subject: string; accuracy: string; requiredClueId: string | null; }
export interface SecretRecord { id: string; ownerId: string; title: string; description: string; revealCondition: string; }

export const worldLocations: WorldLocation[] = [
  { code: 'LOC001', id: 'Bree’s Residence', label: 'Briarwood House', kind: 'HOME', note: 'An elegant residence with a very opinionated foyer and a well-stocked kitchen.' },
  { code: 'LOC002', id: 'Bellamy Residence', label: 'Bellamy Residence', kind: 'RESIDENTIAL', note: 'A warm, slightly chaotic home filled with artwork.' },
  { code: 'LOC003', id: 'Harrow Residence', label: 'Harrow Residence', kind: 'RESIDENTIAL', note: 'A practical household with a remarkably organized workspace.' },
  { code: 'LOC004', id: 'Rose Residence', label: 'Rose Residence', kind: 'RESIDENTIAL', note: 'A polished home with an impressive entertaining room.' },
  { code: 'LOC005', id: 'Vale Residence', label: 'Vale Residence', kind: 'RESIDENTIAL', note: 'A stylish house with an extensive garden and excellent sightlines.' },
  { code: 'LOC006', id: 'Wisteria Green', label: 'Winslow Garden Estate', kind: 'GARDENS', note: 'Traditional flower beds and a lawn ready for a community gathering.' },
  { code: 'LOC007', id: 'Mercer Workshop', label: 'Mercer Workshop', kind: 'WORKSHOP', note: 'Tools, building materials, and a contractor who likes a clear brief.' },
  { code: 'LOC008', id: 'Finch Culinary Studio', label: 'Finch Culinary Studio', kind: 'CULINARY', note: 'A professional kitchen for recipes, practice, and the occasional contest.' },
  { code: 'LOC009', id: 'Neighborhood Press Office', label: 'Neighborhood Press Office', kind: 'BUSINESS', note: 'Local headlines are assembled here, along with several unanswered questions.' },
  { code: 'LOC010', id: 'Rosewood Gardens', label: 'Rosewood Gardens', kind: 'PUBLIC GARDEN', note: 'A landscaped park with seasonal flowers and quiet paths.' },
  { code: 'LOC011', id: 'Community Finance Office', label: 'Community Finance Office', kind: 'BUSINESS', note: 'Budgets are reviewed carefully; numbers have nowhere to hide.' },
  { code: 'LOC012', id: 'Clubhouse', label: 'Briarwood Clubhouse', kind: 'COMMUNITY', note: 'Meetings, neighborhood events, and the occasional spirited disagreement.' },
  { code: 'LOC013', id: 'Market Square', label: 'Grocery Market', kind: 'SHOPS', note: 'A dependable place to replenish the pantry.' },
];

export const worldCharacters: WorldCharacter[] = [
  { id: 'marlow', name: 'Margaret Winslow', role: 'Senior resident', avatar: 'M', description: 'Traditional, proud, and sharper than she lets on; she has gardened on this lane for decades.', opening: 'A supper is a lovely idea. Will the garden be ready in time?', gracious: '“Your garden is a neighborhood treasure. Would you help me choose the seating?”', candid: '“I’m behind schedule. Could you lend me your gardening eye?”', personality: ['Traditional', 'Proud', 'Sharp-minded'], occupation: 'Retired', homeLocationId: 'LOC006', skills: { Gardening: 9, Etiquette: 9, History: 10 }, likes: ['Traditions', 'Flowers', 'Community'], dislikes: ['Loud events'], startingRelationship: 48, secretIds: [] },
  { id: 'susan', name: 'Susan Bellamy', role: 'Neighbor & friend', avatar: 'S', description: 'Warm-hearted, impulsive, and usually one small mishap away from a story.', opening: 'I brought flowers! They were in the car. For a while.', gracious: '“Those flowers are perfect. Let’s give them the best spot.”', candid: '“Next time, let’s bring them in before the stems stage a protest.”', personality: ['Warm', 'Impulsive', 'Curious'], occupation: 'Freelance illustrator', homeLocationId: 'LOC002', skills: { Creativity: 9, Cooking: 3, Investigation: 6, Etiquette: 5 }, likes: ['Art', 'Friendship', 'Coffee'], dislikes: ['Conflict', 'Complicated plans'], startingRelationship: 55, secretIds: ['SEC001'] },
  { id: 'lynette', name: 'Lynette Harrow', role: 'Strategic ally', avatar: 'L', description: 'Practical and determined; she spots the inefficiency in a plan before the tea cools.', opening: 'We should have a better system for community expenses.', gracious: '“You always make the numbers feel manageable. Shall we review them together?”', candid: '“Let’s review every expense before we promise another dollar.”', personality: ['Practical', 'Intelligent', 'Determined'], occupation: 'Business consultant', homeLocationId: 'LOC003', skills: { Strategy: 9, Leadership: 9, Cooking: 5, Investigation: 8 }, likes: ['Efficiency', 'Honesty', 'Family'], dislikes: ['Wasted resources'], startingRelationship: 60, secretIds: ['SEC002'] },
  { id: 'gabriella', name: 'Gabriella Rose', role: 'Social rival & occasional ally', avatar: 'G', description: 'Glamorous, ambitious, and capable of turning a compliment into a negotiation.', opening: 'I hear you’re starting a catering business. How ambitious.', gracious: '“Your eye for presentation is unmatched. Would you collaborate on the menu?”', candid: '“Ambition is useful. I prefer to let the finished table speak.”', personality: ['Glamorous', 'Ambitious', 'Charming'], occupation: 'Fashion entrepreneur', homeLocationId: 'LOC004', skills: { Fashion: 10, Negotiation: 8, Etiquette: 9, Cooking: 4 }, likes: ['Luxury', 'Attention', 'Success'], dislikes: ['Being overlooked'], startingRelationship: 40, secretIds: [] },
  { id: 'edie', name: 'Edith Vale', role: 'Unpredictable neighbor', avatar: 'E', description: 'Witty, competitive, and observant enough to notice a secret trying to leave by the back gate.', opening: 'You wouldn’t believe what I heard yesterday.', gracious: '“You always know the lane better than anyone. What should I actually know?”', candid: '“Is there evidence, or is this just another attractive rumor?”', personality: ['Witty', 'Competitive', 'Observant'], occupation: 'Real estate agent', homeLocationId: 'LOC005', skills: { Investigation: 9, Negotiation: 8, Social: 9 }, likes: ['Gossip', 'Competition', 'Secrets'], dislikes: ['Being excluded'], startingRelationship: 30, secretIds: ['SEC003'] },
  { id: 'oliver', name: 'Oliver Finch', role: 'Butler & estate manager', avatar: 'O', description: 'Calm, loyal, and quietly responsible for the fact that anyone knows where the good tea is.', opening: 'Your appointments are ready. I have also moved the garden visit forward.', gracious: '“Excellent work, Oliver. Please prioritize the garden when you can.”', candid: '“Let’s review the schedule and make room for the urgent things.”', personality: ['Calm', 'Loyal', 'Observant'], occupation: 'Estate manager', homeLocationId: 'LOC001', skills: { Organization: 10, Hospitality: 9, Maintenance: 8 }, likes: ['Order', 'Punctuality', 'Tea'], dislikes: ['Carelessness'], startingRelationship: 75, secretIds: [] },
  { id: 'daniel', name: 'Daniel Mercer', role: 'Local contractor', avatar: 'D', description: 'Friendly and resourceful; he appreciates a clear scope and a realistic budget.', opening: 'The garden beds can be improved. How ambitious are we being?', gracious: '“Your practical advice would make this project easier for everyone.”', candid: '“Let’s agree on the budget before we start moving stone.”', personality: ['Friendly', 'Hardworking', 'Resourceful'], occupation: 'Builder', homeLocationId: 'LOC007', skills: { Construction: 10, Repair: 9, Negotiation: 6 }, likes: ['Tools', 'Projects', 'Reliability'], dislikes: ['Vague plans'], startingRelationship: 50, secretIds: [] },
  { id: 'clara', name: 'Clara Finch', role: 'Head chef', avatar: 'C', description: 'Creative and focused, with high standards for fresh ingredients and clean plating.', opening: 'I’ve misplaced a recipe card. It has to be somewhere in the studio.', gracious: '“Your baking notes are marvelous. May I help you retrace the recipe?”', candid: '“Let’s check the kitchen before the missing card becomes a legend.”', personality: ['Creative', 'Focused', 'Competitive'], occupation: 'Chef', homeLocationId: 'LOC008', skills: { Baking: 10, Cooking: 10, Presentation: 8 }, likes: ['Fresh ingredients', 'Culinary competitions'], dislikes: ['Soggy pastry'], startingRelationship: 45, secretIds: [] },
  { id: 'nathan', name: 'Nathan Cole', role: 'Neighborhood journalist', avatar: 'N', description: 'Curious and analytical; he would rather verify a story than repeat it.', opening: 'An unusual delivery was reported after the community meeting.', gracious: '“I trust your judgment. What details can you confirm?”', candid: '“A report is not proof. Let’s find a source before drawing a conclusion.”', personality: ['Curious', 'Persistent', 'Analytical'], occupation: 'Reporter', homeLocationId: 'LOC009', skills: { Investigation: 10, Writing: 9, Social: 7 }, likes: ['Interesting stories', 'Evidence'], dislikes: ['Unverified claims'], startingRelationship: 42, secretIds: ['SEC004'] },
  { id: 'amelia', name: 'Amelia Hart', role: 'Gardener', avatar: 'A', description: 'Patient and cheerful; she favors sustainable choices and plants that survive a busy week.', opening: 'The roses are lovely, but the soil could use a little attention.', gracious: '“Your garden always feels welcoming. Will you show me what it needs?”', candid: '“Let’s improve the soil first. Pretty flowers can wait their turn.”', personality: ['Patient', 'Cheerful', 'Thoughtful'], occupation: 'Landscape designer', homeLocationId: 'LOC010', skills: { Gardening: 10, Planning: 8 }, likes: ['Roses', 'Sustainability'], dislikes: ['Waste'], startingRelationship: 52, secretIds: [] },
  { id: 'victor', name: 'Victor Hale', role: 'Community treasurer', avatar: 'V', description: 'Analytical and careful with shared funds; he expects every figure to have a reason.', opening: 'The garden proposal needs a clear cost breakdown.', gracious: '“Your careful review will reassure the residents. Shall we check the budget?”', candid: '“Let’s not approve the project until the figures add up.”', personality: ['Conservative', 'Analytical'], occupation: 'Accountant', homeLocationId: 'LOC011', skills: { Finance: 10, Strategy: 8 }, likes: ['Budgets', 'Accuracy'], dislikes: ['Unexplained expenses'], startingRelationship: 46, secretIds: [] },
  { id: 'marlow-friend', name: 'Iris Marlow', role: 'Community volunteer', avatar: 'I', description: 'A generous organizer who makes sure nobody is left out of a neighborhood gathering.', opening: 'Have we saved a seat for the late arrivals?', gracious: '“You always think of everyone. Let’s make the table welcoming.”', candid: '“We need one more place setting before the guests arrive.”', personality: ['Generous', 'Organized', 'Sociable'], occupation: 'Volunteer coordinator', homeLocationId: 'LOC012', skills: { Hospitality: 8, Organization: 8 }, likes: ['Community events', 'Tea'], dislikes: ['Exclusion'], startingRelationship: 50, secretIds: [] },
];

export const missionCatalog: MissionDefinition[] = [
  { id: 'M001', title: 'The Perfect Welcome', type: 'Domestic', difficulty: 'Easy', locationId: 'LOC001', description: 'Prepare the house and welcome the neighbors to an evening in the garden.', objectives: ['Restore order to the foyer', 'Prepare refreshments', 'Welcome a neighbor', 'Host the garden supper'], reward: { currency: 150, experience: 50, prestige: 5 }, playable: true },
  { id: 'M002', title: 'The Missing Recipe', type: 'Investigation', difficulty: 'Medium', locationId: 'LOC008', description: 'Help Clara retrace a missing recipe card.', objectives: ['Speak to Clara', 'Inspect the culinary studio', 'Recover the recipe card'], reward: { currency: 200, experience: 75 }, playable: false },
  { id: 'M003', title: 'A Dinner to Remember', type: 'Culinary', difficulty: 'Medium', locationId: 'LOC001', description: 'Plan a multi-course dinner and keep the guests comfortable.', objectives: ['Select a menu', 'Prepare dinner', 'Host the event'], reward: { currency: 300, experience: 100 }, playable: false },
  { id: 'M004', title: 'The Garden Problem', type: 'Estate', difficulty: 'Easy', locationId: 'LOC006', description: 'Invest in the shared garden and improve community pride.', objectives: ['Review the garden', 'Fund an improvement', 'Raise estate prestige'], reward: { currency: 250, experience: 25, prestige: 10 }, playable: true },
  { id: 'M005', title: 'Unexpected Visitor', type: 'Story', difficulty: 'Medium', locationId: 'LOC001', description: 'A visitor arrives with a request that cannot be scheduled.', objectives: ['Answer the door', 'Choose a response', 'Resolve the visit'], reward: { currency: 0, experience: 125 }, playable: false },
  { id: 'M006', title: 'The Neighborhood Watch', type: 'Action', difficulty: 'Medium', locationId: 'LOC012', description: 'Help restore order at a community gathering using observation and calm choices.', objectives: ['Inspect the clubhouse', 'Speak to witnesses', 'Restore order discreetly'], reward: { currency: 250, experience: 100 }, playable: false },
  { id: 'M007', title: 'The Perfect Cake', type: 'Baking', difficulty: 'Easy', locationId: 'LOC008', description: 'Prepare Bree’s apple cake with a measured hand and a presentable finish.', objectives: ['Gather ingredients', 'Prepare the apple cake', 'Review its quality'], reward: { currency: 125, experience: 75 }, playable: true, unlockRecipeId: 'apple-cake' },
  { id: 'M008', title: 'A Community in Bloom', type: 'Estate', difficulty: 'Medium', locationId: 'LOC006', description: 'Coordinate residents around a more inviting shared garden.', objectives: ['Choose a garden plan', 'Assign help', 'Complete landscaping'], reward: { currency: 400, experience: 100, prestige: 20 }, playable: false },
  { id: 'M009', title: 'The Rumor Mill', type: 'Investigation', difficulty: 'Medium', locationId: 'LOC005', description: 'Separate one persistent neighborhood rumor from what can actually be verified.', objectives: ['Speak with Edith', 'Collect a clue', 'Check the claim'], reward: { currency: 0, experience: 100 }, playable: false },
  { id: 'M010', title: 'The Grand Fundraiser', type: 'Event', difficulty: 'Hard', locationId: 'LOC012', description: 'Plan a larger charity evening that balances hospitality and the budget.', objectives: ['Set a budget', 'Choose a menu', 'Prepare the venue', 'Host the event'], reward: { currency: 750, experience: 200, prestige: 30 }, playable: false },
];
export const clueRecords: ClueRecord[] = [
  { id: 'CLUE001', name: 'Torn Invitation', locationId: 'LOC001', description: 'A fragment of a formal invitation. It establishes a date, but not who misplaced it.', value: 10 },
  { id: 'CLUE002', name: 'Expense Receipt', locationId: 'LOC011', description: 'A community expense receipt that needs a second pair of eyes.', value: 20 },
  { id: 'CLUE003', name: 'Delivery Note', locationId: 'LOC012', description: 'A note showing a delivery time that differs from the public schedule.', value: 15 },
  { id: 'CLUE004', name: 'Garden Photograph', locationId: 'LOC006', description: 'A photograph of the shared garden before its recent restoration.', value: 10 },
];
export const gossipRecords: GossipRecord[] = [
  { id: 'GOSSIP001', sourceId: 'susan', subject: 'A dinner invitation may have gone missing.', accuracy: 'Unknown', requiredClueId: 'CLUE001' },
  { id: 'GOSSIP002', sourceId: 'lynette', subject: 'A community expense may have been recorded twice.', accuracy: 'Partially verified', requiredClueId: 'CLUE002' },
  { id: 'GOSSIP003', sourceId: 'nathan', subject: 'A late delivery arrived after the clubhouse meeting.', accuracy: 'Unverified', requiredClueId: 'CLUE003' },
  { id: 'GOSSIP004', sourceId: 'marlow', subject: 'Residents are discussing the garden restoration proposal.', accuracy: 'Confirmed', requiredClueId: null },
  { id: 'GOSSIP005', sourceId: 'gabriella', subject: 'A neighborhood catering competition may be announced.', accuracy: 'Confirmed', requiredClueId: null },
];
export const secretRecords: SecretRecord[] = [
  { id: 'SEC001', ownerId: 'susan', title: 'The Forgotten Appointment', description: 'Susan is worried she missed an important meeting.', revealCondition: 'Complete the missing-recipe mission.' },
  { id: 'SEC002', ownerId: 'lynette', title: 'The Budget Discrepancy', description: 'Lynette suspects an error in a community expense report.', revealCondition: 'Collect the expense receipt and speak with Lynette.' },
  { id: 'SEC003', ownerId: 'edie', title: 'The Garden Letter', description: 'Edith has found an old note connected to a neighborhood property.', revealCondition: 'Complete the rumor investigation.' },
  { id: 'SEC004', ownerId: 'nathan', title: 'The Unpublished Story', description: 'Nathan has held back one detail from a recent article.', revealCondition: 'Build trust with Nathan.' },
];

export function validateWorldData(): string[] {
  const errors: string[] = [];
  const unique = (label: string, records: { id: string }[]) => {
    const ids = records.map((record) => record.id);
    if (new Set(ids).size !== ids.length) errors.push(`${label}: duplicate ID`);
  };
  unique('characters', worldCharacters);
  unique('missions', missionCatalog);
  unique('recipes', recipes);
  unique('locations', worldLocations.map((location) => ({ id: location.code })));
  const locationIds = new Set(worldLocations.map((location) => location.code));
  const characterIds = new Set(worldCharacters.map((character) => character.id));
  for (const character of worldCharacters) {
    if (!locationIds.has(character.homeLocationId)) errors.push(`Character ${character.id}: missing home location ${character.homeLocationId}`);
    if (character.startingRelationship < 0 || character.startingRelationship > 100) errors.push(`Character ${character.id}: relationship outside 0–100`);
  }
  for (const mission of missionCatalog) {
    if (!locationIds.has(mission.locationId)) errors.push(`Mission ${mission.id}: missing location ${mission.locationId}`);
    if (mission.reward.currency < 0 || mission.reward.experience < 0 || (mission.reward.prestige ?? 0) < 0) errors.push(`Mission ${mission.id}: negative reward`);
    if (mission.unlockRecipeId && !recipes.some((recipe) => recipe.id === mission.unlockRecipeId)) errors.push(`Mission ${mission.id}: missing recipe ${mission.unlockRecipeId}`);
  }
  unique('clues', clueRecords);
  unique('gossip', gossipRecords);
  unique('secrets', secretRecords);
  const clueIds = new Set(clueRecords.map((clue) => clue.id));
  const secretIds = new Set(secretRecords.map((secret) => secret.id));
  for (const recipe of recipes) {
    if (recipe.minutes <= 0) errors.push(`Recipe ${recipe.id}: invalid preparation time`);
    if (Object.values(recipe.ingredients).some((quantity) => !Number.isFinite(quantity) || (quantity ?? 0) <= 0)) errors.push(`Recipe ${recipe.id}: invalid ingredient quantity`);
  }
  for (const character of worldCharacters) for (const secretId of character.secretIds) if (!secretIds.has(secretId)) errors.push(`Character ${character.id}: missing secret ${secretId}`);
  for (const clue of clueRecords) if (!locationIds.has(clue.locationId)) errors.push(`Clue ${clue.id}: missing location ${clue.locationId}`);
  for (const rumor of gossipRecords) {
    if (!characterIds.has(rumor.sourceId)) errors.push(`Gossip ${rumor.id}: missing source ${rumor.sourceId}`);
    if (rumor.requiredClueId && !clueIds.has(rumor.requiredClueId)) errors.push(`Gossip ${rumor.id}: missing clue ${rumor.requiredClueId}`);
  }
  for (const secret of secretRecords) if (!characterIds.has(secret.ownerId)) errors.push(`Secret ${secret.id}: missing owner ${secret.ownerId}`);
  if (!characterIds.has('susan') || !characterIds.has('clara') || !characterIds.has('edie')) errors.push('Required sample residents are missing');
  return errors;
}
