import { describe, expect, it } from 'vitest';
import { freshGame, hasIngredients, hydrateGameState, missionObjectives, neighborhoodStatus, recoverAutosave, reducer } from '../engine/game';
import { recipes } from '../data/content';
import { clueRecords, missionCatalog, validateWorldData, worldCharacters, worldLocations } from '../data/world';

describe('BREE shared game loop', () => {
  it('initializes a complete profile with a starter pantry', () => {
    const game = freshGame('Ada');
    expect(game.playerName).toBe('Ada');
    expect(game.inventory.flour).toBe(3);
    expect(missionObjectives(game).filter((item) => item.done)).toHaveLength(0);
    expect(game.needDifficulty).toBe('standard');
    expect(game.weather).toBe('Sunny');
  });
  it('advances the calendar, applies need difficulty and expenses, and triggers a spaced event', () => {
    const start = freshGame();
    const dayTwo = reducer(start, { type: 'newDay' });
    expect(dayTwo.day).toBe(2);
    expect(dayTwo.hour).toBe(8);
    expect(dayTwo.funds).toBe(start.funds - 25);
    expect(dayTwo.hunger).toBe(50);
    expect(dayTwo.weather).toBe('Cloudy');
    expect(dayTwo.season).toBe('Spring');
    const dayThree = reducer(dayTwo, { type: 'newDay' });
    expect(dayThree.dailyEvent).toBeTruthy();
    expect(dayThree.log[0]).toContain(dayThree.dailyEvent);
    const relaxed = reducer({ ...start, needDifficulty: 'relaxed' }, { type: 'newDay' });
    const challenging = reducer({ ...start, needDifficulty: 'challenging' }, { type: 'newDay' });
    expect(relaxed.hunger).toBeGreaterThan(dayTwo.hunger);
    expect(challenging.hunger).toBeLessThan(dayTwo.hunger);
  });
  it('runs daily activities and respects outdoor weather restrictions', () => {
    const start = freshGame();
    const breakfast = reducer(start, { type: 'activity', activity: 'breakfast' });
    expect(breakfast.funds).toBe(start.funds - 8);
    expect(breakfast.hunger).toBeGreaterThan(start.hunger);
    const watered = reducer(start, { type: 'activity', activity: 'water-garden' });
    expect(watered.householdCondition).toBeGreaterThan(start.householdCondition);
    const storm = { ...start, weather: 'Stormy' as const };
    expect(reducer(storm, { type: 'activity', activity: 'water-garden' })).toBe(storm);
    expect(neighborhoodStatus(watered).score).toBeGreaterThan(0);
    expect(neighborhoodStatus(watered).rows).toHaveLength(7);
  });

  it('consumes recipe ingredients and updates time, energy, and dish quality', () => {
    const start = freshGame();
    const tart = recipes.find((recipe) => recipe.id === 'lemon-tart')!;
    const next = reducer(start, { type: 'cook', recipe: tart });
    expect(next.dish?.name).toBe('Lemon tart');
    expect(next.inventory.flour).toBe(2);
    expect(next.inventory.lemon).toBe(1);
    expect(next.hour * 60 + next.minute).toBe(8 * 60 + 35);
    expect(next.energy).toBeLessThan(start.energy);
  });

  it('unlocks the supper after tidying, cooking, and greeting; then grants its rewards once', () => {
    let state = freshGame();
    state = reducer(state, { type: 'tidy' });
    state = reducer(state, { type: 'talk', characterId: 'marlow', characterName: 'Mrs. Marlow', tone: 'gracious', delta: 8 });
    state = reducer(state, { type: 'cook', recipe: recipes[0] });
    const before = state.funds;
    state = reducer(state, { type: 'host' });
    expect(state.hosted).toBe(true);
    expect(state.missionComplete).toBe(true);
    expect(state.completedMissionIds).toContain('M001');
    expect(state.funds).toBeGreaterThan(before);
    expect(missionObjectives(state).every((item) => item.done)).toBe(true);
    const duplicate = reducer(state, { type: 'host' });
    expect(duplicate.funds).toBe(state.funds);
    const nextDay = reducer(state, { type: 'newDay' });
    const replay = reducer({ ...nextDay, tidied: true, greeted: true, dish: state.dish }, { type: 'host' });
    expect(replay.funds).toBe(nextDay.funds);
    expect(replay.missionComplete).toBe(true);
  });

  it('does not allow cooking without sufficient stock or energy', () => {
    const start = { ...freshGame(), energy: 2 };
    const next = reducer(start, { type: 'cook', recipe: recipes[0] });
    expect(next).toBe(start);
    expect(hasIngredients({ ...start.inventory, flour: 0 }, recipes[0].ingredients)).toBe(false);
  });

  it('charges the pantry basket and applies estate upgrades to shared funds', () => {
    const start = freshGame();
    const shopped = reducer(start, { type: 'shop' });
    expect(shopped.funds).toBe(192);
    expect(shopped.inventory.flour).toBe(5);
    const upgraded = reducer(shopped, { type: 'upgrade' });
    expect(upgraded.funds).toBe(352);
    expect(upgraded.completedMissionIds).toContain('M004');
    expect(upgraded.estateLevel).toBe(1);
    expect(upgraded.prestige).toBeGreaterThan(start.prestige);
    const repeatUpgrade = reducer(upgraded, { type: 'upgrade' });
    expect(repeatUpgrade.funds).toBe(197);
    expect(repeatUpgrade.completedMissionIds.filter((id) => id === 'M004')).toHaveLength(1);
  });

  it('awards the perfect-cake mission once and records investigated clues', () => {
    const cake = recipes.find((recipe) => recipe.id === 'apple-cake')!;
    const start = freshGame();
    const baked = reducer(start, { type: 'cook', recipe: cake });
    expect(baked.completedMissionIds).toContain('M007');
    expect(baked.funds).toBe(start.funds + 125);
    expect(baked.xp).toBeGreaterThan(start.xp + 18);
    const clue = reducer(baked, { type: 'investigate', clueId: 'CLUE001' });
    expect(clue.collectedClues).toContain('CLUE001');
    expect(clue.location).toBe('Bree’s Residence');
    expect(reducer(clue, { type: 'investigate', clueId: 'CLUE001' })).toBe(clue);
  });

  it('migrates pre-expansion saves without losing player progress', () => {
    const legacy = { ...freshGame('Ada'), funds: 777, missionComplete: true } as Record<string, unknown>;
    delete legacy.completedMissionIds;
    delete legacy.collectedClues;
    delete legacy.hunger;
    delete legacy.cleanliness;
    delete legacy.socialFulfillment;
    delete legacy.householdCondition;
    delete legacy.needDifficulty;
    delete legacy.weather;
    delete legacy.season;
    delete legacy.dailyEvent;
    const restored = hydrateGameState(legacy);
    expect(restored.playerName).toBe('Ada');
    expect(restored.funds).toBe(777);
    expect(restored.completedMissionIds).toContain('M001');
    expect(restored.collectedClues).toEqual([]);
    expect(restored.relationships.clara).toBeDefined();
    expect(restored.hunger).toBe(freshGame().hunger);
    expect(restored.needDifficulty).toBe('standard');
    expect(restored.weather).toBe('Sunny');
  });
  it('preserves a damaged autosave while restoring the last known-good snapshot', () => {
    const backup = JSON.stringify({ ...freshGame('Ada'), funds: 876 });
    const result = recoverAutosave('{broken-json', backup);
    expect(result.state.playerName).toBe('Ada');
    expect(result.state.funds).toBe(876);
    expect(result.source).toBe('backup');
    expect(result.damagedPrimary).toBe('{broken-json');
    const noBackup = recoverAutosave('{broken-json', null);
    expect(noBackup.source).toBe('fresh');
    expect(noBackup.damagedPrimary).toBe('{broken-json');
  });

  it('validates the sample campaign content references and unique IDs', () => {
    expect(validateWorldData()).toEqual([]);
    expect(worldCharacters).toHaveLength(12);
    expect(worldLocations).toHaveLength(13);
    expect(missionCatalog).toHaveLength(10);
    expect(clueRecords).toHaveLength(4);
  });

  it('keeps character relationships within the visible 0–100 range', () => {
    const start = { ...freshGame(), relationships: { marlow: 98 } };
    const next = reducer(start, { type: 'talk', characterId: 'marlow', characterName: 'Mrs. Marlow', tone: 'gracious', delta: 8 });
    expect(next.relationships.marlow).toBe(100);
    expect(next.greeted).toBe(true);
  });
});
