# BREE — The Garden Supper

A browser-first React + TypeScript prototype. Prepare a neighborhood supper while balancing cooking, relationships, household needs, local reputation, and community investment.

## Run it

Requires Node.js 20.19+ or 22.12+ (Vite 8 requirement).

```bash
npm install
npm run dev
```

Use the local URL printed by Vite. Validate and preview a production build with `npm run build` and `npm run preview`; run the gameplay suite with `npm test`.

## Playable systems

- **Campaign slice:** three playable missions: M001 *The Perfect Welcome*, M004 *The Garden Problem*, and M007 *The Perfect Cake*. Rewards are guarded against repeat collection.
- **Residents and places:** 12 resident profiles, 13 explorable locations, dialogue choices, relationship changes, and a journal with four clues, five rumors, and four secret records.
- **Cooking:** 15 recipes, a typed ingredient pantry, cooking time and quality, and a market restock.
- **Daily loop:** needs for energy, composure, hunger, cleanliness, social fulfillment, and household condition. Four repeatable activities are available: breakfast, watering the garden, reading the bulletin, and checking messages. Tidy, talk, cook, host, and rest also affect household state.
- **Changing world:** calendar days, morning/afternoon/evening/night periods, four seven-day seasons, six weather states, a $25 daybreak upkeep cost, and a seeded neighborhood event on every third day. Rain, storms, and snow prevent watering; season influences garden improvement.
- **Status report:** seven neighborhood measures and a composite score respond to relationships, finances, community cohesion, estate improvements, season, weather, and upkeep.
- **Adjustable pace:** relaxed, standard, and challenging need decay settings.
- **Persistence:** autosaves, three manual keepsake slots, v1 save hydration, and a rotating last-known-good autosave backup. If an autosave is corrupt, the game preserves its raw contents locally, restores a valid backup when available, and shows a notice rather than silently dropping the original.

The typed static mock-world dataset and its validator are in `src/data/world.ts`; recipes are in `src/data/content.ts`. The reducer, score calculations, daily simulation, save hydration, and autosave recovery are in `src/engine/game.ts`.

## Project structure

```text
bree-game/
  public/                 Favicon and static assets
  src/app/                React screens and responsive styles
  src/data/               Recipes, resident profiles, missions, evidence records
  src/engine/              Shared game reducer, calendar, scoring, saves, migration
  src/tests/               Gameplay, content integrity, migration, and recovery tests
  src/types/               Shared TypeScript types
  FEATURE_AUDIT.md         Implemented/partial/not implemented scope audit
  package.json
  package-lock.json
  vite.config.ts
```

## Known limits

This is a focused game slice, not the full improvement plan. It does not contain 100 recipes/missions/activities, the requested large content database, character schedules or autonomous movement, staff assignment, full catering contracts, action missions, broad estate customization, policy voting, multiplayer, AI dialogue, or a multi-chapter branching campaign. See [FEATURE_AUDIT.md](FEATURE_AUDIT.md) for explicit status by feature group. The game has no account, backend, cloud sync, analytics, or remote services; data stays in this browser and can be removed by clearing site storage.
